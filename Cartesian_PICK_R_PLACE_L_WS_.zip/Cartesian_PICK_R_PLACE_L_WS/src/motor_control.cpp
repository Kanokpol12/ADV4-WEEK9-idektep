#include <Arduino.h>
#include "motor_control.h" 
#include <AccelStepper.h>
#include <stdint.h>
#include <Servo.h>

Servo myservo1; // Gripper
Servo myservo2; // Rotator

#define MOTORX_STEP_PIN 2
#define MOTORX_DIR_PIN 5
#define MOTORY_STEP_PIN 3
#define MOTORY_DIR_PIN 6
#define MOTORZ_STEP_PIN 4
#define MOTORZ_DIR_PIN 7

//---------- Limit switch ----------//
#define LIMITSWITCHX_PIN 9
#define LIMITSWITCHY_PIN 10
#define LIMITSWITCHZ_PIN 11
#define INTERRUPT_PIN 99 
//---------------------------------//

// <<< --- CONSTANTS FOR MOVEMENT --- >>>
int MICROSTEP_RES = 16;
int STEPRATE = 50;
int TO_MILLI = 10; 

// !!! คุณต้องวัดค่านี้ในหน่วย mm !!!
const float PICK_TO_PLACE_X_OFFSET = -________; // ค่าของตำแหน่งแกน x ที่จะนำ Object ไปวาง โดยลบออกจาก Pick ที่ตำแหน่งแรก เช่น -150,-160,...
// <<< --- END CONSTANTS --- >>>


// <<< --- SOFTWARE LIMITS --- >>>
// !!! คุณต้องวัดระยะทาง (mm) สูงสุดที่หุ่นยนต์เคลื่อนที่ได้จริง !!!
// !!! วัดจากจุด Work Home (0,0,0) ไปยังจุดไกลสุดของแต่ละแกน !!!
const float MAX_TRAVEL_X = 180.0; // (mm) ตัวอย่าง: 500mm ปรับค่านี้
const float MAX_TRAVEL_Y = 185.0; // (mm) ตัวอย่าง: 400mm ปรับค่านี้
const float MAX_TRAVEL_Z = 160.0; // (mm) ตัวอย่าง: 120mm ปรับค่านี้

// ค่าต่ำสุด (คำนวณจาก homePosition)
// นี่คือพิกัดของ Limit Switch เทียบกับ Work Home (0,0,0)
const float MIN_TRAVEL_X = -47.8; // (mm) เช่น มาจาก moveTomm(48.5, ...)    ใน set home position
const float MIN_TRAVEL_Y = -1;  // (mm) เช่น มาจาก moveTomm(..., 1, ...)  ใน set home position
const float MIN_TRAVEL_Z = -3;  // (mm) เช่น มาจาก moveTomm(..., ..., 3)  ใน set home position
// <<< --- END SOFTWARE LIMITS --- >>>


volatile bool INTERRUPT_FLAG = false;

AccelStepper MOTORX(AccelStepper::DRIVER, MOTORX_STEP_PIN, MOTORX_DIR_PIN);
AccelStepper MOTORY(AccelStepper::DRIVER, MOTORY_STEP_PIN, MOTORY_DIR_PIN);
AccelStepper MOTORZ(AccelStepper::DRIVER, MOTORZ_STEP_PIN, MOTORZ_DIR_PIN);


void motorSetup(uint16_t maxSpeed, uint16_t maxAccel)
{
    pinMode(LIMITSWITCHX_PIN, INPUT_PULLUP);
    pinMode(LIMITSWITCHY_PIN, INPUT_PULLUP);
    pinMode(LIMITSWITCHZ_PIN, INPUT_PULLUP);

    MOTORX.setMaxSpeed(maxSpeed);
    MOTORY.setMaxSpeed(maxSpeed);
    MOTORZ.setMaxSpeed(maxSpeed);
    MOTORX.setAcceleration(maxAccel);
    MOTORY.setAcceleration(maxAccel);
    MOTORZ.setAcceleration(maxAccel);

    myservo1.attach(12); // Gripper Servo
    myservo2.attach(13); // Rotator Servo
}

//----------------Home position -----------------//
// (นี่คือเวอร์ชันล่าสุดที่คุณให้มา)
void homePosition()
{
    // --- Z-Axis Homing ---
    MOTORZ.setSpeed(-3000); 
    while (digitalRead(LIMITSWITCHZ_PIN) == HIGH)
    {
        MOTORZ.runSpeed();
    }
    MOTORZ.setCurrentPosition(0); // นี่คือ Machine Zero (Z)
    MOTORZ.moveTo(10); // ยกขึ้นเล็กน้อย
    MOTORZ.runToPosition();

    // --- Y-Axis Homing ---
    MOTORY.setSpeed(-3000); 
    while (digitalRead(LIMITSWITCHY_PIN) == HIGH)
    {
        MOTORY.runSpeed();
    }
    MOTORY.setCurrentPosition(0); // นี่คือ Machine Zero (Y)
    MOTORY.moveTo(10); // ถอยออก
    MOTORY.runToPosition();

    // --- X-Axis Homing ---
    MOTORX.setSpeed(-3000); 
    while (digitalRead(LIMITSWITCHX_PIN) == HIGH)
    {
        MOTORX.runSpeed();
    }
    MOTORX.setCurrentPosition(0); // นี่คือ Machine Zero (X)
    MOTORX.moveTo(10); // ถอยออก
    MOTORX.runToPosition();

    // --- เคลื่อนที่ไปยัง Work Home (Work Offset) ---
    // การเรียก moveTomm() ตรงนี้จะใช้ "Machine Coordinates" (0,0,0 ที่สวิตช์)
    // แต่ moveTomm() มี Software Limit... เราต้องระวัง
    // *** หมายเหตุ: การเรียก moveTomm() ที่นี่ อาจถูกจำกัดโดย Software Limit
    // เราจะแก้ปัญหานี้โดยการย้ายการตั้งค่า 0 ไปหลังการเคลื่อนที่
    
    //Set Homposition ใหม่
    float targetX_steps = 47.8 * MICROSTEP_RES * STEPRATE / TO_MILLI; // (mm) เช่น (48.5, ...)    ใน set home position
    float targetY_steps = 1 * MICROSTEP_RES * STEPRATE / TO_MILLI;  // (mm) เช่น (...,1 ...)    ใน set home position
    float targetZ_steps = 3 * MICROSTEP_RES * STEPRATE / TO_MILLI;  // (mm) เช่น (...,...,3)    ใน set home position

    MOTORX.moveTo(targetX_steps);
    MOTORY.moveTo(targetY_steps);
    MOTORZ.moveTo(targetZ_steps);
    
    while (MOTORX.distanceToGo() != 0 || MOTORY.distanceToGo() != 0 || MOTORZ.distanceToGo() != 0)
    {
        MOTORX.run();
        MOTORY.run();
        MOTORZ.run();
    }
    
    // 2. ตั้งค่า "Home" ใหม่
    //    ณ จุดนี้ พิกัด (0,0,0) ใหม่ของเราคือ (Machine 48.5, 1, 3)
    MOTORX.setCurrentPosition(0); 
    MOTORY.setCurrentPosition(0);
    MOTORZ.setCurrentPosition(0);
    
    delay(1000);
}

//---------------------------------------------------------//

void moveTomm(float targetX, float targetY, float targetZ)
{
    // <<< --- MODIFIED: CONSTRAIN TARGETS (SOFTWARE LIMITS) --- >>>
    // ตรวจสอบว่าเป้าหมายไม่เกินค่าสูงสุด หรือต่ำกว่า "ค่าต่ำสุด" (ที่สวิตช์)
    
    if (targetX < MIN_TRAVEL_X) { 
        targetX = MIN_TRAVEL_X;  
        Serial.print("Warning: X target < MIN, setting to ");
        Serial.println(MIN_TRAVEL_X);
    }
    if (targetX > MAX_TRAVEL_X) {
        targetX = MAX_TRAVEL_X;
        Serial.print("Warning: X target > MAX, setting to ");
        Serial.println(MAX_TRAVEL_X);
    }
    
    if (targetY < MIN_TRAVEL_Y) { 
        targetY = MIN_TRAVEL_Y;  
        Serial.print("Warning: Y target < MIN, setting to ");
        Serial.println(MIN_TRAVEL_Y);
    }
    if (targetY > MAX_TRAVEL_Y) {
        targetY = MAX_TRAVEL_Y;
        Serial.print("Warning: Y target > MAX, setting to ");
        Serial.println(MAX_TRAVEL_Y);
    }

    if (targetZ < MIN_TRAVEL_Z) { 
        targetZ = MIN_TRAVEL_Z;  
        Serial.print("Warning: Z target < MIN, setting to ");
        Serial.println(MIN_TRAVEL_Z);
    }
    if (targetZ > MAX_TRAVEL_Z) {
        targetZ = MAX_TRAVEL_Z;
        Serial.print("Warning: Z target > MAX, setting to ");
        Serial.println(MAX_TRAVEL_Z);
    }
    // <<< --- END MODIFIED --- >>>


    MOTORX.setSpeed(10000); 
    MOTORY.setSpeed(10000); 
    MOTORZ.setSpeed(10000); 

    float stepsX = targetX * MICROSTEP_RES * STEPRATE / TO_MILLI;
    float stepsY = targetY * MICROSTEP_RES * STEPRATE / TO_MILLI;
    float stepsZ = targetZ * MICROSTEP_RES * STEPRATE / TO_MILLI;

    MOTORX.moveTo(stepsX);
    MOTORY.moveTo(stepsY);
    MOTORZ.moveTo(stepsZ);

    while (MOTORX.distanceToGo() != 0 || MOTORY.distanceToGo() != 0 || MOTORZ.distanceToGo() != 0)
    {
        if (INTERRUPT_FLAG)
        {
            interruptLoop();
            Serial.println("Cartesian was interrupted..!");
            resetBoard();
            break; 
        }
        else
        {
            // <<< --- HARDWARE SAFETY STOP (for 0-end) --- >>>
            // ถ้าชนสวิตช์ (LOW) และกำลังเคลื่อนที่เข้าหาสวิตช์ (speed < 0)
            if (digitalRead(LIMITSWITCHX_PIN) == LOW && MOTORX.speed() < 0) {
                MOTORX.stop(); // หยุดทันที
                // ตั้งค่าตำแหน่งปัจจุบัน (ในหน่วย steps) ให้ตรงกับค่า MIN ที่สวิตช์อยู่
                MOTORX.setCurrentPosition(MIN_TRAVEL_X * MICROSTEP_RES * STEPRATE / TO_MILLI); 
            } else {
                MOTORX.run();
            }

            if (digitalRead(LIMITSWITCHY_PIN) == LOW && MOTORY.speed() < 0) {
                MOTORY.stop();
                MOTORY.setCurrentPosition(MIN_TRAVEL_Y * MICROSTEP_RES * STEPRATE / TO_MILLI);
            } else {
                MOTORY.run();
            }

            if (digitalRead(LIMITSWITCHZ_PIN) == LOW && MOTORZ.speed() < 0) {
                MOTORZ.stop();
                MOTORZ.setCurrentPosition(MIN_TRAVEL_Z * MICROSTEP_RES * STEPRATE / TO_MILLI);
            } else {
                MOTORZ.run();
            }
            // <<< --- END HARDWARE SAFETY --- >>>
        }
    }

    Serial.print("Moved to X: ");
    Serial.print(targetX);
    Serial.print(" mm, Y: ");
    Serial.print(targetY);
    Serial.print(" mm, Z: ");
    Serial.print(targetZ);
    Serial.println(" mm");
}

//----------------------------------- Servo control ---------------//
void Gripped(float pos)
{
    myservo1.write(pos); // 25 [ grasp ] --- 160 [ release ]
}

void Rotate(float pos)
{
    myservo2.write(pos); // 9 [ 0 deg.]   --- 102 [ 90 deg.]
}

//-----------------------------------------------------------------//

void interruptLoop()
{
    INTERRUPT_FLAG = true; 
}

void resetBoard()
{
    Serial.println("Arduino reset...");
    delay(1000);
    asm volatile("  jmp 0"); 
}


//
// <<< --- MODIFIED FUNCTION --- >>>
//
void receiveSerialCommand()
{
    if (Serial.available())
    {
        String command = Serial.readStringUntil('\n');
        command.trim(); // ลบช่องว่างหน้า-หลัง

        // <<< ADDED CHECK >>>
        // ถ้า command เป็นค่าว่าง (เช่น ได้รับแค่ \n หรือสัญญาณรบกวน)
        if (command.length() == 0) {
            return; 
        }
        // <<< END ADDED CHECK >>>

        if (command == "home")
        {
            Serial.println("Start homing...");
            homePosition();
            Serial.println("Sethome position"); // แจ้งกลับ Python
        }
        else if (command == "ready")
        {
            Serial.println("Ready to detect"); // แจ้งกลับ Python
        }
        else if (command.startsWith("G"))
        {
            int xIndex = command.indexOf('X');
            int yIndex = command.indexOf('Y');

            if (xIndex > 0 && yIndex > 0)
            {
                float x = command.substring(xIndex + 1, yIndex).toFloat();
                float y = command.substring(yIndex + 1).toFloat();
                //==============================================================================
                float x_place = x + PICK_TO_PLACE_X_OFFSET; 
                //==============================================================================
                Serial.print("Picking from X:");
                Serial.print(x);
                Serial.print(" Y:");
                Serial.println(y);
                Serial.print("Placing at X:");
                Serial.print(x_place);
                Serial.print(" Y:");
                Serial.println(y);

                //------------ Pick and Place Sequence ------------------//
                
                // 1. ไปที่ตำแหน่ง "หยิบ" (Z = 0 คือด้านบน)
                moveTomm(___, ___, 0); // Z=0 คือ Work Home (Z=-3 คือสวิตช์)
                Rotate(9); 
                delay(1000);

                // 2. ลงไป "หยิบ"
                moveTomm(___, ___, 112); // Z ลงไปหยิบ
                Gripped(25); // หนีบ
                delay(1000); 

                // 3. ยกวัตถุขึ้น
                moveTomm(___, ___, 0); 
                delay(1000); 

                // 4. ไปที่ตำแหน่ง "วาง" (X ใหม่, Y เดิม, Z ด้านบน)
                moveTomm(___, ___, 0);
                delay(1000);
                
                // 5. ลงไป "วาง"
                moveTomm(___, ___, 108); // Z ลงไปวาง
                Gripped(150); // ปล่อย
                delay(1000); 

                // 6. ยกขึ้น และกลับ Home
                moveTomm(___, ___, 0); 
                delay(500);
                homePosition();
                Serial.println("Sucess to pick and place objects"); // แจ้งกลับ Python
            }
        }
        else
        {
            // แก้ไข Error message ให้ชัดเจนขึ้น
            Serial.print("Unknown command: [");
            Serial.print(command);
            Serial.println("]");
        }
    }
}

//-----------------------------------------------------------------//
// <<< --- ARDUINO MAIN FUNCTIONS --- >>>
//-----------------------------------------------------------------//

// void setup() {
//   Serial.begin(115200);
//   motorSetup(10000, 10000); // กำหนด MaxSpeed, MaxAccel ที่เหมาะสม
  
//   Serial.println("Board Started. Waiting for 'home' command...");
//   // เราจะรอคำสั่ง 'home' จาก Python แทนการ Homing ทันที
// }

// void loop() {
//   receiveSerialCommand();
// }